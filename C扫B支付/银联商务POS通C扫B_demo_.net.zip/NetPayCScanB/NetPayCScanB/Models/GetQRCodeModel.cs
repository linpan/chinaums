﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace NetPayCScanB.Models
{
    public class GetQRCodeModel
    {
        //[Required]
        //[Display(Name = "商户号")]
        //public string mid { get; set; }

        //[Required]
        //[Display(Name = "终端号")]
        //public string tid { get; set; }

        //[Required]
        //[Display(Name = "业务类型")]
        //public string instMid { get; set; }

        [Required]
        [Display(Name = "账单号")]
        public string billNo { get; set; }

        [Required]
        [Display(Name = "账单日期 yyyy-MM-dd")]
        public string billDate { get; set; }

        [Required]
        [Display(Name = "支付总金额，单位为分")]
        public string totalAmount { get; set; }

        [Display(Name = "支付结果通知地址")]
        public string notifyUrl { get; set; }

        [Display(Name = "网页跳转地址")]
        public string returnUrl { get; set; }

        [Display(Name = "请求系统预留字段")]
        public string srcReserve { get; set; }
    }
}