﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace NetPayCScanB.Models
{
    public class BillRefundModel
    {
        [Required]
        [Display(Name = "商户号")]
        public string mid { get; set; }

        [Required]
        [Display(Name = "终端号")]
        public string tid { get; set; }

        [Required]
        [Display(Name = "业务类型")]
        public string instMid { get; set; }

        [Required]
        [Display(Name = "账单号")]
        public string billNo { get; set; }

        [Required]
        [Display(Name = "账单日期 yyyy-MM-dd")]
        public string billDate { get; set; }

        [Required]
        [Display(Name = "要退款的金额，单位为分")]
        public string refundAmount { get; set; }
    }
}