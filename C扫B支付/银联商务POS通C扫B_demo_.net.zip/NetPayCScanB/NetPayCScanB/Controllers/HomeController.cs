﻿using NetPayCScanB.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using NetPayCScanB.Util;
using Newtonsoft.Json;
using System.Drawing;
using ThoughtWorks.QRCode.Codec;
using System.Text;
using System.IO;
using System.Drawing.Imaging;

namespace NetPayCScanB.Controllers
{
    public class HomeController : Controller
    {
        string mid = "898340149000005";
        string tid = "88880001";
        string instMid = "QRPAYDEFAULT";
        string msgSrc = "WWW.TEST.COM";
        string msgSrcId = "3194";
        string md5Key = "fcAmtnx7MwismjWNhNKdHC44mNXtnEQeJkRrhKJwyrW2ysRR";
       

        public ActionResult Index()
        {
            ViewBag.Message = "银联商务POS通插件C扫B业务示例程序。";

            return View();
        }

        public ActionResult GetQRCode()
        {
            ViewBag.Message = "获取二维码。";

            return View();
        }

        // POST: /Home/GetQRCode
        [HttpPost]
        public ActionResult GetQRCode(GetQRCodeModel model)
        {
            ViewBag.Message = "获取二维码";

            string apiUrl = "https://qr-test2.chinaums.com/netpay-route-server/api/";

            Dictionary<string, string> requestParams = new Dictionary<string, string>();
            DateTime nowTime = DateTime.Now;
            string billNo = msgSrcId + "wktest" + nowTime.ToString("yyyyMMddhhmmss");
            string billDate = nowTime.ToString("yyyy-MM-dd");

            requestParams.Add("msgSrc", msgSrc);
            requestParams.Add("msgType", "bills.getQRCode");
            requestParams.Add("mid", mid);
            requestParams.Add("tid", tid);
            requestParams.Add("billNo", billNo);
            requestParams.Add("billDate", billDate);
            requestParams.Add("totalAmount", model.totalAmount);

            requestParams.Add("instMid", instMid);
            requestParams.Add("requestTimestamp", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
            requestParams.Add("sign", Utils.MakeSign(requestParams, md5Key));

            string requestJsonString = JsonConvert.SerializeObject(requestParams);

            string responseJsonString = Utils.CreateHttpPostRequest(requestJsonString, apiUrl);

            Dictionary<string, string> jsonParams = JsonConvert.DeserializeObject<Dictionary<string, string>>(responseJsonString);

            // 验证返回数据的签名
            if (Utils.CheckSign(jsonParams, md5Key))
            {
                foreach (var item in jsonParams)
                    Console.Out.WriteLine(item.ToString());

                DisplayQRCodeModel getQRCodeResult = JsonConvert.DeserializeObject<DisplayQRCodeModel>(responseJsonString);
                return RedirectToAction("DisplayQRCode", getQRCodeResult);
            }

            return View();
        }

        public ActionResult DisplayQRCode(DisplayQRCodeModel model)
        {
            ViewBag.Message = "显示获取的二维码";

            if (string.Equals(model.errCode, "SUCCESS"))
            {
                //初始化二维码生成工具
                QRCodeEncoder qrCodeEncoder = new QRCodeEncoder();
                qrCodeEncoder.QRCodeEncodeMode = QRCodeEncoder.ENCODE_MODE.BYTE;
                qrCodeEncoder.QRCodeErrorCorrect = QRCodeEncoder.ERROR_CORRECTION.M;
                qrCodeEncoder.QRCodeVersion = 0;
                qrCodeEncoder.QRCodeScale = 4;

                //将字符串生成二维码图片
                Bitmap image = qrCodeEncoder.Encode(model.billQRCode, Encoding.Default);

                //保存为PNG到内存流  
                MemoryStream ms = new MemoryStream();
                image.Save(ms, ImageFormat.Png);
                image.Dispose();
                Response.ClearContent();
                Response.ContentType = "image/gif";
                //输出二维码图片
                Response.BinaryWrite(ms.GetBuffer());
                Response.End();
            }

            return View();
        }

        // GET: /Home/BillsQuery
        public ActionResult BillsQuery()
        {
            ViewBag.Message = "账单状态查询";

            return View();
        }

        // POST: /Home/BillsQuery
        [HttpPost]
        public ActionResult BillsQuery(BillsQueryModel model)
        {
            ViewBag.Message = "账单状态查询";

            string apiUrl = "https://qr-test2.chinaums.com/netpay-route-server/api/";

            Dictionary<string, string> requestParams = new Dictionary<string, string>();

            requestParams.Add("msgSrc", msgSrc);
            requestParams.Add("msgType", "bills.query");
            requestParams.Add("mid", model.mid);
            requestParams.Add("tid", model.tid);
            requestParams.Add("instMid",instMid);
            requestParams.Add("billNo", model.billNo);
            requestParams.Add("billDate", model.billDate);
            requestParams.Add("requestTimestamp", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
            requestParams.Add("sign", Utils.MakeSign(requestParams, md5Key));

            string requestJsonString = JsonConvert.SerializeObject(requestParams);

            string responseJsonString = Utils.CreateHttpPostRequest(requestJsonString, apiUrl);

            Dictionary<string, string> responseJsonParams = Utils.ParseMultiJsonObject(responseJsonString);

            // 验证返回数据的签名
            if (Utils.CheckSign(responseJsonParams, md5Key))
            {
                DisplayBillsQueryResultModel queryResult = JsonConvert.DeserializeObject<DisplayBillsQueryResultModel>(responseJsonString);
                return RedirectToAction("DisplayBillsQueryResult", queryResult);
            }
            return View();
        }

        public ActionResult DisplayBillsQueryResult(DisplayBillsQueryResultModel model)
        {
            ViewBag.Message = "账单状态查询结果显示";

            return View();
        }

        // GET: /Home/BillRefund
        public ActionResult BillRefund()
        {
            ViewBag.Message = "账单退款示例";

            return View();
        }

        // POST: /Home/BillRefund
        [HttpPost]
        public ActionResult BillRefund(BillRefundModel model)
        {
            ViewBag.Message = "账单退款示例";

            string apiUrl = "https://qr-test2.chinaums.com/netpay-route-server/api/";

            Dictionary<string, string> requestParams = new Dictionary<string, string>();

            requestParams.Add("msgSrc", msgSrc);
            requestParams.Add("msgType", "bills.refund");
            requestParams.Add("mid", model.mid);
            requestParams.Add("tid", model.tid);
            requestParams.Add("instMid", instMid);
            requestParams.Add("billNo", model.billNo);
            requestParams.Add("billDate", model.billDate);
            requestParams.Add("refundAmount", model.refundAmount);
            requestParams.Add("requestTimestamp", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
            requestParams.Add("sign", Utils.MakeSign(requestParams, md5Key));

            string requestJsonString = JsonConvert.SerializeObject(requestParams);

            string responseJsonString = Utils.CreateHttpPostRequest(requestJsonString, apiUrl);

            Dictionary<string, string> responseJsonParams = Utils.ParseMultiJsonObject(responseJsonString);

            // 验证返回数据的签名
            if (Utils.CheckSign(responseJsonParams, md5Key))
            {
                DisplayBillRefundResultModel refundResult = JsonConvert.DeserializeObject<DisplayBillRefundResultModel>(responseJsonString);
                return RedirectToAction("DisplayBillRefundResult", refundResult);
            }
            return View();
        }

        public ActionResult DisplayBillRefundResult(DisplayBillRefundResultModel model)
        {
            ViewBag.Message = "显示账单退款结果";

            return View();
        }

        // POST:  /Home/ReceiveNotifyUrlData
        [HttpPost]
        public String ReceiveNotifyUrlData()
        {
            ViewBag.Message = "接收通知数据";

            Dictionary<String, String> notifyData = new Dictionary<string, string>();
            try
            {
                // 不要用固定的数据格式处理通知数据，后续系统可能会添加参数
                foreach (var key in Request.Form.AllKeys)
                {
                    notifyData.Add(key, Request.Form[key]);
                }

                if (Utils.CheckSign(notifyData, md5Key))
                {
                    return "SUCCESS";
                }
            }
            catch (Exception ex)
            {
                return "FAILED";
            }

            return "FAILED";
        }

        // GET:  //Home/ReceiveReturnUrlData
        public string ReceiveReturnUrlData()
        {
            ViewBag.Message = "接收返回数据";

            Dictionary<string, string> returnUrlData = new Dictionary<string, string>();
            try
            {
                // 不要用固定的数据格式处理返回数据，后续系统可能会添加参数
                foreach (var key in Request.QueryString.AllKeys)
                {
                    returnUrlData.Add(key, Request.QueryString[key]);
                }
                if (Utils.CheckSign(returnUrlData, md5Key))
                {
                    return "returnUrl返回数据验证成功：" + JsonConvert.SerializeObject(returnUrlData);
                }
            }
            catch (Exception ex)
            {
                return "returnUrl返回数据验证失败：" + JsonConvert.SerializeObject(returnUrlData);
            }
            return "returnUrl返回数据验证失败：" + JsonConvert.SerializeObject(returnUrlData);
        }
    }
}
